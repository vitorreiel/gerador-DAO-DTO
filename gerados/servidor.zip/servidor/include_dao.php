<?php
	require_once('conexao.php');
 	
	require_once('DAO/RequisicaoDAO.php');
	require_once('DTO/Requisicao.php');

?>