<?php
	require_once('conexao.php');
 	
	require_once('DAO/AdmDAO.php');
	require_once('DTO/Adm.php');
	require_once('DAO/EmpresasDAO.php');
	require_once('DTO/Empresas.php');
	require_once('DAO/HistoricoDAO.php');
	require_once('DTO/Historico.php');
	require_once('DAO/UserDAO.php');
	require_once('DTO/User.php');

?>