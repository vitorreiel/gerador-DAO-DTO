<?php
	require_once('conexao.php');
 	
	require_once('DAO/AdminDAO.php');
	require_once('DTO/Admin.php');
	require_once('DAO/ProdutosDAO.php');
	require_once('DTO/Produtos.php');

?>