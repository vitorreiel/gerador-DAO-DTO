<?php

	/* @Autor: Dalker Pinheiro
	   Include com todas as Classes e os arquivos de DAO */

	require_once('conexao.php');
 	
	require_once('DAO/EventosDAO.php');
	require_once('DTO/Eventos.php');

?>