<?php
	require_once('conexao.php');
 	
	require_once('DAO/HistoricoDAO.php');
	require_once('DTO/Historico.php');

?>