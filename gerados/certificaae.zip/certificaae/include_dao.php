<?php

	/* @Autor: Dalker Pinheiro
	   Include com todas as Classes e os arquivos de DAO */

	require_once('conexao.php');
 	
	require_once('DAO/EventoDAO.php');
	require_once('DTO/Evento.php');
	require_once('DAO/OficinaDAO.php');
	require_once('DTO/Oficina.php');
	require_once('DAO/Oficina_palestranteDAO.php');
	require_once('DTO/Oficina_palestrante.php');
	require_once('DAO/Oficina_participanteDAO.php');
	require_once('DTO/Oficina_participante.php');
	require_once('DAO/PalestranteDAO.php');
	require_once('DTO/Palestrante.php');
	require_once('DAO/ParticipanteDAO.php');
	require_once('DTO/Participante.php');
	require_once('DAO/UsuarioDAO.php');
	require_once('DTO/Usuario.php');

?>