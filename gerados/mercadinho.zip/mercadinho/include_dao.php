<?php
	require_once('conexao.php');
 	
	require_once('DAO/ClienteDAO.php');
	require_once('DTO/Cliente.php');
	require_once('DAO/MensalDAO.php');
	require_once('DTO/Mensal.php');
	require_once('DAO/MovimentacaoDAO.php');
	require_once('DTO/Movimentacao.php');
	require_once('DAO/RetiradaDAO.php');
	require_once('DTO/Retirada.php');
	require_once('DAO/Retirada2DAO.php');
	require_once('DTO/Retirada2.php');
	require_once('DAO/UserDAO.php');
	require_once('DTO/User.php');

?>