<?php
	require_once('conexao.php');
 	
	require_once('DAO/AdminDAO.php');
	require_once('DTO/Admin.php');
	require_once('DAO/ClienteDAO.php');
	require_once('DTO/Cliente.php');
	require_once('DAO/EmpresaDAO.php');
	require_once('DTO/Empresa.php');
	require_once('DAO/TecnicoDAO.php');
	require_once('DTO/Tecnico.php');

?>